# SOEN387-A1
 
Tools used and versions
Tomcat v10.1
jdk-17.0.3.1
Eclipse 2023-09

Instructions:
To generate the .war file, proceed to Eclipse and right click the project. Navigate to Export and then select WAR file. Afterwards, make sure the project you want is selected and choose the destination for the WAR file. Then click on finish.
On the webpage, there are currently two users you can login as (or you can choose to not login and be an anonymous user and the website will still function accordingly). The first user is username:aaa password:aaa. They have the same functions and permissions as the anonymous user. The second user is the admin user with username:admin password:secret. This user gains access to various extra functions such as editing products, creating products, and more (all the required ones).
